	
		function calculateSI(pa, roi, noy) {
			if(pa.value == "" || roi.value == "" 
				|| noy.value =="")
			{
				alert('Plz fill all text boxes ..!');
			}
			else{
			var si = parseFloat(pa.value) *
				parseFloat(roi.value) *
				   parseFloat(noy.value) / 100;
			
	// HTML DOM [Document Object Modeling]
	//document.getElementById("result").innerHTML
	//		="Simple Interest is "+si;	

	alert("Simple Interest is "+si);
		}
	}
